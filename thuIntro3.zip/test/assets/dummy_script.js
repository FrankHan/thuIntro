// Dummy script to test script loading
window.dummy_loaded = true;
