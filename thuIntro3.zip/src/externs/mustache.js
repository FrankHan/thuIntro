/**
 * @type {!Object}
 */
var Mustache;

/**
 * @type {!string}
 */
Mustache.name;

/**
 * @type {!string}
 */
Mustache.version;

/**
 * @type {function(!string, !Object, Object=, function(!string)=): ?string}
 */
Mustache.to_html = function (template, view, partials, send_fun) {};
