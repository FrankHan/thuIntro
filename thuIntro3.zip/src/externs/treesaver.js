/**
 * @type {?boolean}
 */
window.TS_NO_AUTOLOAD;

/**
 * @type {?boolean}
 */
window.TS_NO_AUTOMETRICS;

/**
 * @type {?boolean}
 */
window.TS_SLOW_DEVICE;

/**
 * @type {?boolean}
 */
window.TS_WITHIN_NATIVE_IOS_APP;
